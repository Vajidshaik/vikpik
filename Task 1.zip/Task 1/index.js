// Data Types //

{
let a='sweet'
console.log(typeof a, a)
// output:string //
}

{
let a=4
console.log(typeof a,a)
// output:Number //
}

{
let a=10
let b=20
let z=a>b
console.log(typeof z,z)
/*boolean*/
}
{
 let a=null
 console.log(typeof a,a)
 /*null object*/
}

 console.log(typeof c,c)
 var c=20
 //undefined//



/*Operators*/

let a=80
let b=60
console.log('addition',a+b)
console.log('sub',a-b)
console.log('multiplication',a*b)
console.log('division',a/b)
console.log('modulus',a%b)

//Comparator Operators//
let k=15
let v="17"
console.log("equal to",k==v)
console.log("===",k===v)
console.log("not equal to",k!=v)
console.log("!==",k!==v)
let s=31
let q=31
console.log("greater than",s>q)
console.log("less than",s<q)
console.log("greater than or equal to",s>=q)
console.log("less than or equal to",s<=q)


//Output//
/*string sweet
number 4
boolean false
object null
undefined undefined
addition 90
sub -30
multiplication 1800
division 0.5
modulus 30
equal to false
=== false
not equal to true
!== true
greater than false
less than false
greater than or equal to true
less than or equal to true
PS C:\Users\kalug\OneDrive\Desktop\Task 1>  node index.js
string sweet
number 4
boolean false
object null
undefined undefined
addition 140
sub 20
multiplication 4800
division 1.3333333333333333
modulus 20
equal to false
=== false
not equal to true
!== true
greater than false
less than false
greater than or equal to true
less than or equal to true*/
